// B Pharma Pathshala frontend. Configure Supabase in config.js before enabling live data.
const CONFIG = window.BPP_CONFIG || { supabaseUrl: "", supabaseAnonKey: "", oldSyllabusPath: "assets/old-aktu-bpharm-syllabus-2019-20.pdf", newSyllabusPath: "assets/new-bpharm-syllabus.pdf" };
const sb = (CONFIG.supabaseUrl && CONFIG.supabaseAnonKey && window.supabase) ? window.supabase.createClient(CONFIG.supabaseUrl, CONFIG.supabaseAnonKey) : null;
const $ = (id) => document.getElementById(id);
const planData = {
  old:{name:"Old AKTU B.Pharm Notes",amount:199,validity:"8 months"},
  new:{name:"New B.Pharm Notes",amount:249,validity:"8 months"},
  dpharm:{name:"D.Pharm Batch",amount:899,validity:"1 year"},
  bpharm_iq:{name:"B.Pharm Important Questions",amount:49,validity:"Set by admin"},
  dpharm_iq:{name:"D.Pharm Important Questions",amount:149,validity:"Set by admin"}
};
$("menuToggle").addEventListener("click",()=> $("nav").classList.toggle("open"));
document.querySelectorAll("#nav a").forEach(a=>a.addEventListener("click",()=> $("nav").classList.remove("open")));
$("loginOpen").addEventListener("click",()=> $("loginDialog").showModal());
document.querySelectorAll(".choose-plan").forEach(btn=>btn.addEventListener("click",()=>{
  $("payPlan").value=btn.dataset.plan; $("payment").scrollIntoView({behavior:"smooth"}); updateWhatsApp();
}));
function updateWhatsApp(){
  const plan=planData[$("payPlan").value]; const name=$("payName").value.trim();
  const msg=`Hello B Pharma Pathshala, I need payment help.%0AName: ${encodeURIComponent(name)}%0APlan: ${encodeURIComponent(plan?plan.name:"Not selected")}%0AAmount: ${plan?"₹"+plan.amount:"Not selected"}`;
  $("whatsPay").href="https://wa.me/918006020616?text="+msg;
}
$("payPlan").addEventListener("change",updateWhatsApp); $("payName").addEventListener("input",updateWhatsApp);
$("oldView").addEventListener("click",()=>openPdf(CONFIG.oldSyllabusPath));
$("oldDownload").addEventListener("click",()=>downloadPdf(CONFIG.oldSyllabusPath,"old-aktu-bpharm-syllabus-2019-20.pdf"));
$("newView").addEventListener("click",()=>openPdf(CONFIG.newSyllabusPath));
$("newDownload").addEventListener("click",()=>downloadPdf(CONFIG.newSyllabusPath,"new-bpharm-syllabus.pdf"));
function openPdf(path){fetch(path,{method:"HEAD"}).then(r=>{if(r.ok)window.open(path,"_blank","noopener");else alert("Syllabus PDF not uploaded yet. Add the PDF at: "+path)}).catch(()=>alert("Syllabus PDF not uploaded yet. Add the PDF at: "+path))}
function downloadPdf(path,name){fetch(path,{method:"HEAD"}).then(r=>{if(r.ok){const a=document.createElement("a");a.href=path;a.download=name;a.click()}else alert("Syllabus PDF not uploaded yet. Add the PDF at: "+path)}).catch(()=>alert("Syllabus PDF not uploaded yet. Add the PDF at: "+path))}
$("paymentForm").addEventListener("submit",async e=>{
 e.preventDefault();
 if(!sb){$("paymentMessage").textContent="Supabase is not configured yet. Your details were NOT submitted. Complete SETUP.md first.";return}
 const studentName=$("payName").value.trim(), mobile=$("payMobile").value.trim(), planKey=$("payPlan").value, utr=$("payUtr").value.trim();
 const plan=planData[planKey]; if(!plan){$("paymentMessage").textContent="Please select a plan.";return}
 let screenshotPath=null; const file=$("payScreenshot").files[0];
 try{
   if(file){const ext=file.name.split(".").pop().toLowerCase();const path=`payment-proofs/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const up=await sb.storage.from("payment-proofs").upload(path,file,{upsert:false}); if(up.error)throw up.error; screenshotPath=path;}
   const {error}=await sb.from("payment_requests").insert({student_name:studentName,mobile,plan_key:planKey,plan_name:plan.name,amount:plan.amount,semester:$("paySemester").value?Number($("paySemester").value):null,utr,screenshot_path:screenshotPath,status:"pending"});
   if(error)throw error;
   $("paymentMessage").textContent="Payment request submitted as Pending. Access is granted only after admin verification.";
   e.target.reset(); updateWhatsApp();
 }catch(err){$("paymentMessage").textContent="Could not submit request: "+(err.message||"configuration or permission error");}
});
$("sendOtp").addEventListener("click",async()=>{
 if(!sb){$("loginMessage").textContent="Supabase phone authentication is not configured. See SETUP.md.";return}
 const phone=$("loginPhone").value.replace(/\D/g,""); if(phone.length!==10){$("loginMessage").textContent="Enter a valid 10-digit Indian mobile number.";return}
 const {error}=await sb.auth.signInWithOtp({phone:"+91"+phone,options:{channel:"sms"}});
 $("loginMessage").textContent=error?error.message:"OTP request sent if phone authentication is configured.";
});
$("verifyOtp").addEventListener("click",async()=>{
 if(!sb){$("loginMessage").textContent="Supabase is not configured. See SETUP.md.";return}
 const phone=$("loginPhone").value.replace(/\D/g,""), token=$("otpValue").value.trim(), name=$("loginName").value.trim();
 const {data,error}=await sb.auth.verifyOtp({phone:"+91"+phone,token,type:"sms"});
 if(error){$("loginMessage").textContent=error.message;return}
 if(name && data.user){await sb.from("profiles").upsert({id:data.user.id,full_name:name,mobile:"+91"+phone},{onConflict:"id"});}
 const {data:profile}=await sb.from("profiles").select("role,full_name").eq("id",data.user.id).maybeSingle();
 $("loginMessage").textContent=profile?.role==="admin"?"Admin login successful. Admin panel is now available.":"Student login successful.";
 if(profile?.role==="admin"){ $("adminPanel").hidden=false; $("adminPanel").scrollIntoView({behavior:"smooth"}); }
});
async function loadPlans(){
 if(!sb)return;
 const {data,error}=await sb.from("pricing_plans").select("*").eq("active",true).order("sort_order");
 if(error||!data?.length)return;
 $("plansGrid").innerHTML=data.map(p=>`<article class="plan"><span class="plan-tag">${escapeHtml(p.category||"COURSE")}</span><h3>${escapeHtml(p.title)}</h3><div class="price">₹${Number(p.price)} <small>${p.price_unit?"/ "+escapeHtml(p.price_unit):""}</small></div><p>${p.validity_months?`${p.validity_months} months access`:p.validity_days?`${p.validity_days} days access`:escapeHtml(p.validity_label||"Validity set by admin")}</p><button class="btn blue-btn choose-plan" data-plan="${escapeHtml(p.plan_key)}">Choose plan</button></article>`).join("");
 document.querySelectorAll(".choose-plan").forEach(btn=>btn.addEventListener("click",()=>{if(planData[btn.dataset.plan])$("payPlan").value=btn.dataset.plan;$("payment").scrollIntoView({behavior:"smooth"});updateWhatsApp()}));
}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function loadNotes(){
 if(!sb)return;
 let q=sb.from("notes").select("id,title,description,syllabus_type,semester,subject,unit,category,storage_path,is_paid").eq("published",true).order("created_at",{ascending:false});
 if($("filterSyllabus").value)q=q.eq("syllabus_type",$("filterSyllabus").value);
 if($("filterSemester").value)q=q.eq("semester",Number($("filterSemester").value));
 const term=$("filterSearch").value.trim(); if(term)q=q.or(`title.ilike.%${term}%,subject.ilike.%${term}%`);
 const {data,error}=await q;
 if(error){$("notesList").innerHTML='<div class="empty-state">Notes could not load. Check Supabase configuration and policies.</div>';return}
 if(!data?.length){$("notesList").innerHTML='<div class="empty-state">No published notes match your filters yet.</div>';return}
 $("notesList").innerHTML=data.map(n=>`<article class="info-card note-row"><h3>${escapeHtml(n.title)}</h3><p>${escapeHtml(n.subject||"")} ${n.semester?`· Semester ${n.semester}`:""} ${n.unit?`· Unit ${n.unit}`:""}</p><p>${escapeHtml(n.description||"")}</p><button class="btn blue-btn" data-file="${escapeHtml(n.storage_path)}" data-paid="${n.is_paid}">Open PDF</button></article>`).join("");
 document.querySelectorAll("[data-file]").forEach(b=>b.addEventListener("click",async()=>{const {data,error}=await sb.storage.from("study-materials").createSignedUrl(b.dataset.file,60);if(error)alert("Could not open file. Sign in and confirm access permissions.");else window.open(data.signedUrl,"_blank","noopener")}));
}
$("searchNotes").addEventListener("click",loadNotes);
$("filterSyllabus").addEventListener("change",loadNotes); $("filterSemester").addEventListener("change",loadNotes);
// Admin upload: requires Supabase auth, notes table policies and study-materials storage bucket.
$("adminType").addEventListener("change",()=>{
 const d=$("adminType").value==="dpharm";
 $("adminSemester").innerHTML=d?'<option value="1">D.Pharm Part I</option><option value="2">D.Pharm Part II</option>':'<option value="1">Semester 1</option><option value="2">Semester 2</option><option value="3">Semester 3</option><option value="4">Semester 4</option><option value="5">Semester 5</option><option value="6">Semester 6</option><option value="7">Semester 7</option><option value="8">Semester 8</option>';
});
$("adminUploadForm").addEventListener("submit",async e=>{
 e.preventDefault();
 if(!sb){$("adminUploadMessage").textContent="Supabase is not configured. Fill config.js first.";return}
 const {data:{user}}=await sb.auth.getUser();
 if(!user){$("adminUploadMessage").textContent="Please login first using Admin Login.";return}
 const {data:profile,error:profileError}=await sb.from("profiles").select("role").eq("id",user.id).maybeSingle();
 if(profileError||profile?.role!=="admin"){$("adminUploadMessage").textContent="Access denied. This account does not have admin role.";return}
 const file=$("adminFile").files[0]; if(!file){$("adminUploadMessage").textContent="Select a file to upload.";return}
 const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,"-");
 const path=`${$("adminType").value}/${$("adminSemester").value}/${Date.now()}-${safeName}`;
 $("adminUploadMessage").textContent="Uploading file…";
 try{
  const up=await sb.storage.from("study-materials").upload(path,file,{upsert:false});
  if(up.error)throw up.error;
  const {error}=await sb.from("notes").insert({
   title:$("adminTitle").value.trim(),description:$("adminDescription").value.trim(),
   syllabus_type:$("adminType").value,semester:Number($("adminSemester").value),
   subject:$("adminSubject").value.trim(),unit:$("adminUnit").value.trim(),
   category:$("adminCategory").value,storage_path:path,is_paid:$("adminPaid").checked,
   published:$("adminPublish").checked,created_by:user.id
  });
  if(error){await sb.storage.from("study-materials").remove([path]);throw error}
  $("adminUploadMessage").textContent="Upload saved successfully. "+($("adminPublish").checked?"Material is published.":"Material is saved as draft.");
  e.target.reset(); loadNotes();
 }catch(err){$("adminUploadMessage").textContent="Upload failed: "+(err.message||"Check storage bucket and admin policies.");}
});
loadPlans(); loadNotes();
