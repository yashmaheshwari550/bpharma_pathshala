-- Run in Supabase SQL Editor after creating a new project.
-- Review/test policies before launch. The public anon key is safe only with RLS.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  mobile text unique,
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
create policy "profiles_read_own" on public.profiles for select to authenticated using (id = auth.uid() or exists(select 1 from public.profiles me where me.id=auth.uid() and me.role='admin'));
create policy "profiles_insert_own_student" on public.profiles for insert to authenticated with check (id=auth.uid() and role='student');
create policy "profiles_update_own_name" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid() and role='student');

create table if not exists public.pricing_plans (
 id uuid primary key default gen_random_uuid(),
 plan_key text unique not null,
 title text not null,
 category text not null default 'COURSE',
 price numeric(10,2) not null check(price>=0),
 price_unit text,
 validity_months integer,
 validity_days integer,
 validity_label text,
 active boolean not null default true,
 sort_order integer not null default 0,
 updated_at timestamptz not null default now()
);
alter table public.pricing_plans enable row level security;
create policy "plans_public_read_active" on public.pricing_plans for select to anon,authenticated using (active=true);
create policy "plans_admin_all" on public.pricing_plans for all to authenticated using (exists(select 1 from public.profiles where id=auth.uid() and role='admin')) with check (exists(select 1 from public.profiles where id=auth.uid() and role='admin'));

insert into public.pricing_plans(plan_key,title,category,price,price_unit,validity_months,validity_label,sort_order) values
('old','Old AKTU B.Pharm Notes','B.PHARM',199,'semester',8,'8 months',1),
('new','New B.Pharm Notes','B.PHARM',249,'semester',8,'8 months',2),
('dpharm','D.Pharm Batch','D.PHARM',899,null,12,'1 year',3),
('bpharm_iq','B.Pharm Important Questions','QUESTION BANK',49,null,null,'Set by admin',4),
('dpharm_iq','D.Pharm Important Questions','QUESTION BANK',149,null,null,'Set by admin',5)
on conflict(plan_key) do nothing;

create table if not exists public.notes (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 description text,
 syllabus_type text not null check(syllabus_type in ('old','new','dpharm')),
 semester integer check(semester between 1 and 8),
 subject text,
 unit text,
 category text not null default 'Notes',
 storage_path text not null,
 is_paid boolean not null default true,
 published boolean not null default false,
 created_by uuid references auth.users(id),
 created_at timestamptz not null default now()
);
alter table public.notes enable row level security;
create policy "notes_public_read_published_metadata" on public.notes for select to anon,authenticated using (published=true);
create policy "notes_admin_manage" on public.notes for all to authenticated using (exists(select 1 from public.profiles where id=auth.uid() and role='admin')) with check (exists(select 1 from public.profiles where id=auth.uid() and role='admin'));

create table if not exists public.payment_requests (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references auth.users(id),
 student_name text not null,
 mobile text not null,
 plan_key text not null,
 plan_name text not null,
 amount numeric(10,2) not null check(amount>=0),
 semester integer check(semester between 1 and 8),
 utr text not null,
 screenshot_path text,
 status text not null default 'pending' check(status in ('pending','approved','rejected')),
 admin_note text,
 reviewed_by uuid references auth.users(id),
 reviewed_at timestamptz,
 created_at timestamptz not null default now()
);
create unique index if not exists payment_requests_utr_unique on public.payment_requests(utr);
alter table public.payment_requests enable row level security;
create policy "payment_insert_authenticated" on public.payment_requests for insert to authenticated with check (user_id=auth.uid());
create policy "payment_read_own_or_admin" on public.payment_requests for select to authenticated using (user_id=auth.uid() or exists(select 1 from public.profiles where id=auth.uid() and role='admin'));
create policy "payment_admin_update" on public.payment_requests for update to authenticated using (exists(select 1 from public.profiles where id=auth.uid() and role='admin')) with check (exists(select 1 from public.profiles where id=auth.uid() and role='admin'));

create table if not exists public.purchases (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id),
 payment_request_id uuid unique references public.payment_requests(id),
 plan_key text not null,
 plan_name text not null,
 amount_paid numeric(10,2) not null,
 semester integer,
 purchased_at timestamptz not null default now(),
 access_starts_at timestamptz not null default now(),
 expires_at timestamptz,
 status text not null default 'active' check(status in ('active','expired','revoked')),
 created_at timestamptz not null default now()
);
alter table public.purchases enable row level security;
create policy "purchases_read_own_or_admin" on public.purchases for select to authenticated using (user_id=auth.uid() or exists(select 1 from public.profiles where id=auth.uid() and role='admin'));
create policy "purchases_admin_manage" on public.purchases for all to authenticated using (exists(select 1 from public.profiles where id=auth.uid() and role='admin')) with check (exists(select 1 from public.profiles where id=auth.uid() and role='admin'));

-- IMPORTANT SETUP:
-- 1) Create Storage buckets: study-materials (private), payment-proofs (private), site-assets (public or controlled).
-- 2) Add bucket policies: only admins upload/manage study-materials; students should receive signed URLs only after purchase validation.
-- 3) Set the first admin manually from a trusted SQL Editor session after the user has registered:
--    update public.profiles set role='admin' where mobile='+91XXXXXXXXXX';
-- 4) Production-grade access enforcement for paid notes should use an Edge Function/RPC that checks approved purchases and expiry before issuing signed URLs.
-- 5) Payment screenshot storage and student payment insert should be tied to auth.uid(); public unauthenticated submissions are intentionally not allowed.
