// Copy this file to config.js and fill in your Supabase project URL and anon/public key.
// The anon key is intended for browser use only when RLS is configured correctly.
// NEVER place a Supabase service_role key here.
window.BPP_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT.supabase.co",
  supabaseAnonKey: "YOUR_SUPABASE_ANON_PUBLIC_KEY",
  oldSyllabusPath: "assets/old-aktu-bpharm-syllabus-2019-20.pdf",
  newSyllabusPath: "assets/new-bpharm-syllabus.pdf"
};