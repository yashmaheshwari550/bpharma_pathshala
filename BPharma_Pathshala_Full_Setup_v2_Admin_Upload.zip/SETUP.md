# B Pharma Pathshala — Setup Guide

This is a working starter project for the new website. The UI and BharatPe QR are included. Real authentication, database-backed notes/pricing and payment requests require your own Supabase project configuration.

## Included
- Premium blue/orange responsive website.
- BharatPe QR image supplied in this chat (`assets/bharatpe-qr.jpg`).
- Plan pricing display.
- Old/New syllabus view/download controls.
- Notes library UI and Supabase queries.
- Student phone OTP UI using Supabase Auth.
- Manual UTR/payment proof submission UI.
- WhatsApp support link: https://wa.me/918006020616
- Supabase schema starter: `supabase/schema.sql`.

## 1. Add your real logo
Your actual logo file has not been supplied separately in this project. Upload it as `assets/logo.png`, then update the brand markup in `index.html` to use that file. Do not replace your real logo with a placeholder.

## 2. Add syllabus PDFs
Place the uploaded old AKTU syllabus at:
`assets/old-aktu-bpharm-syllabus-2019-20.pdf`
When you receive the new syllabus PDF, place it at:
`assets/new-bpharm-syllabus.pdf`
The new PDF is not included because it has not been supplied.

## 3. Configure Supabase
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Supabase Authentication, enable Phone sign-in and configure a real SMS/OTP provider. SMS providers may require paid credentials.
4. Copy `config.example.js` to `config.js`.
5. Put your Supabase Project URL and anon/public key in `config.js`. Never put a service_role key in browser code.
6. Create private Storage buckets named `study-materials` and `payment-proofs`, and a bucket named `site-assets` if you want editable branding assets.
7. Configure Storage policies before uploading private or paid files. Do not make paid PDFs public.
8. Register your admin phone number, then use trusted Supabase SQL Editor to promote that exact profile to admin:
   `update public.profiles set role='admin' where mobile='+91YOURNUMBER';`
   Verify the row before running this command. Never expose admin promotion in the public website.

## 4. Payment workflow
This site uses manual UPI QR payment, not automatic payment gateway verification. A student pays by QR and submits UTR/screenshot. Admin checks the payment in BharatPe and approves or rejects it. Do not grant paid access merely because a form was submitted.

The supplied front-end payment submission expects an authenticated student and the matching RLS policies. Add an admin-only review interface/Edge Function to approve requests and create a purchase record with the correct expiry. The starter SQL does not itself implement a complete payment approval workflow.

## 5. Important production limitations
- Admin dashboard UI for approving payments and uploading notes must still be built/configured.
- Secure signed-file delivery must validate approved purchases and expiry on the server/Edge Function.
- OTP works only after configuring Supabase phone auth and SMS provider.
- Policies/SQL must be tested in your own project before collecting real student data or payments.
- Important Questions validity is admin-controlled and should be set before advertising a fixed duration.
- Privacy, Terms and Refund policies should be reviewed and published before launch.

## 6. Run locally
This is a static HTML/CSS/JS project. Serve the folder with any static web server or deploy to a static host. Do not open `index.html` as a local file if you need Supabase auth/storage; use a local server or deployed HTTPS site.

## Files
- `index.html` — site layout
- `styles.css` — responsive blue/orange design
- `app.js` — front-end interactions and Supabase calls
- `config.example.js` — Supabase configuration template
- `supabase/schema.sql` — starter database schema
- `assets/bharatpe-qr.jpg` — supplied QR image


## Admin notes upload (added in this build)
1. Deploy the updated `index.html`, `app.js`, and `styles.css` together.
2. Configure `config.js` with your Supabase project URL and anon/public key. Never put a service-role key in website files.
3. In Supabase Storage, create a private bucket named `study-materials`. Configure policies so only authenticated admins can upload/delete; students should only get signed URLs for material they are entitled to access.
4. Run `supabase/schema.sql` in Supabase SQL Editor.
5. Student must log in once using phone OTP so a `profiles` row exists. In Supabase SQL Editor, assign the owner's account as admin by replacing the phone number:
   `update public.profiles set role='admin' where mobile='+91YOUR10DIGITNUMBER';`
   Confirm the exact mobile value in `profiles` before running.
6. Log in again on the site. Admin Panel appears after successful login only if `profiles.role = 'admin'`. Use it to upload PDFs/documents and classify them as Old AKTU, New B.Pharm, or D.Pharm; choose semester (1–8) or D.Pharm Part I/II, subject, unit, category, and publish/draft.
7. Important: this frontend upload form depends on correct Supabase RLS and Storage policies. Test with a student account and an admin account before public launch. Do not publish paid files through a public storage bucket. Paid entitlement enforcement must be implemented server-side before accepting real payments.
